# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: networkModeCrud.spec.ts >> board CRUD over the network >> create, rename, and delete a board via the UI round-trips through real REST calls
- Location: e2e/networkModeCrud.spec.ts:159:3

# Error details

```
Test timeout of 45000ms exceeded.
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - generic [ref=e3]:
    - generic [ref=e4]:
      - button "Close settings" [ref=e5]
      - dialog [ref=e6]:
        - heading "Connection settings" [level=2] [ref=e7]
        - generic [ref=e12]:
          - generic [ref=e13]:
            - generic [ref=e14]: Base URL
            - textbox "Base URL" [ref=e15]:
              - /placeholder: http://localhost:1996
          - generic [ref=e16]:
            - generic [ref=e17]: Auth token (optional)
            - textbox "Auth token (optional)" [ref=e18]:
              - /placeholder: "Sent as Authorization: Bearer <token>"
          - generic [ref=e19]:
            - checkbox "Persist token to this browser's local storage" [ref=e20]
            - generic [ref=e21]: Persist token to this browser's local storage
        - generic [ref=e22]:
          - button "Cancel" [ref=e23] [cursor=pointer]
          - button "Save & Connect" [disabled] [ref=e24]
    - generic [ref=e25]:
      - generic [ref=e26]: kanvy
      - link "Home" [ref=e28] [cursor=pointer]:
        - /url: /
      - button "Change view mode" [ref=e33] [cursor=pointer]
      - button "Switch to dark mode" [ref=e37] [cursor=pointer]
      - button "Import a board from a JSON file" [ref=e40] [cursor=pointer]
      - button "Download the board as a JSON file" [ref=e44] [cursor=pointer]
      - button "Settings" [active] [ref=e48] [cursor=pointer]
    - generic [ref=e54]:
      - button "Keyboard shortcuts" [ref=e55] [cursor=pointer]
      - switch "Switch to Network mode" [ref=e59] [cursor=pointer]
      - generic [ref=e63]:
        - button "Zoom out" [ref=e64] [cursor=pointer]
        - button "100%" [ref=e68] [cursor=pointer]
        - button "Zoom in" [ref=e69] [cursor=pointer]
  - button "Open Tanstack query devtools" [ref=e123] [cursor=pointer]
```