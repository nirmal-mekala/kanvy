# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: multiboard.spec.ts >> the breadcrumb shows only the home icon on root, with no editable title
- Location: e2e/multiboard.spec.ts:82:1

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('.breadcrumb__title')
Expected: 0
Received: 1
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" locator('.breadcrumb__title') with timeout 5000ms
  - waiting for locator('.breadcrumb__title')
    14 × locator resolved to 1 element
       - unexpected value "1"

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - generic [ref=e3]:
    - generic [ref=e4]:
      - generic [ref=e5]: kanvy
      - generic [ref=e6]:
        - link "Home" [ref=e7] [cursor=pointer]:
          - /url: /
        - generic [aria-hidden] [ref=e11]: /
        - generic [ref=e12]:
          - generic [ref=e13]: My Kanvy Board
          - button "Edit board name" [ref=e14] [cursor=pointer]
      - button "Change view mode" [ref=e19] [cursor=pointer]
      - button "Switch to dark mode" [ref=e23] [cursor=pointer]
      - button "Import a board from a JSON file" [ref=e26] [cursor=pointer]
      - button "Download the board as a JSON file" [ref=e30] [cursor=pointer]
      - button "Settings" [ref=e34] [cursor=pointer]
    - generic [ref=e38]:
      - textbox "Card caption" [ref=e43]:
        - /placeholder: Write something...
        - text: Welcome to Kanvy Double-click the canvas to add a note.
      - generic [ref=e44]:
        - button "Keyboard shortcuts" [ref=e45] [cursor=pointer]
        - switch "Switch to Network mode" [ref=e49] [cursor=pointer]
        - generic [ref=e53]:
          - button "Zoom out" [ref=e54] [cursor=pointer]
          - button "100%" [ref=e58] [cursor=pointer]
          - button "Zoom in" [ref=e59] [cursor=pointer]
  - button "Open Tanstack query devtools" [ref=e113] [cursor=pointer]
```

# Test source

```ts
  1   | import { expect, test } from '@playwright/test'
  2   | import { seedBoard } from './fixtures/board'
  3   | import { dispatchPaste } from './fixtures/clipboard'
  4   | 
  5   | // Multiboard support, Sub-phases 3-4 (ctx/notes/260917-multiboard-
  6   | // implementation-plan.md §5-6): TanStack Router adoption,
  7   | // `/`(home) + `/$boardId` routes, breadcrumb (Sub-phase 3), then the
  8   | // `board` card kind itself — create/rename/click-to-navigate, root
  9   | // content-gating (Sub-phase 4). The Sub-phase 3 tests below seed a schema
  10  | // v3 document with a second board directly into localStorage (no
  11  | // board-creation UI existed yet at that point); the Sub-phase 4 tests
  12  | // exercise the real create-a-board-from-the-UI flow end to end.
  13  | 
  14  | const NOW = '2026-01-01T00:00:00.000Z'
  15  | 
  16  | const ROOT_CARD = {
  17  |   id: 'root-card',
  18  |   boardId: 'root',
  19  |   type: 'card',
  20  |   kind: 'text',
  21  |   size: 'regular',
  22  |   x: 100,
  23  |   y: 100,
  24  |   w: 224,
  25  |   h: 90,
  26  |   color: 'gray',
  27  |   content: 'Root content',
  28  |   createdAt: NOW,
  29  |   updatedAt: NOW,
  30  | }
  31  | 
  32  | const CHILD_CARD = {
  33  |   ...ROOT_CARD,
  34  |   id: 'child-card',
  35  |   boardId: 'child-1',
  36  |   content: 'Child content',
  37  | }
  38  | 
  39  | const TWO_BOARD_DOCUMENT = {
  40  |   version: 3,
  41  |   nodes: [ROOT_CARD, CHILD_CARD],
  42  |   edges: [],
  43  |   boards: [
  44  |     {
  45  |       id: 'root',
  46  |       title: 'Home',
  47  |       status: 'active',
  48  |       createdAt: NOW,
  49  |       updatedAt: NOW,
  50  |     },
  51  |     {
  52  |       id: 'child-1',
  53  |       title: 'Untitled board',
  54  |       status: 'active',
  55  |       createdAt: NOW,
  56  |       updatedAt: NOW,
  57  |     },
  58  |   ],
  59  |   images: {},
  60  | }
  61  | 
  62  | test('the root path is the home board', async ({ page }) => {
  63  |   await page.goto('/')
  64  |   await expect(page).toHaveURL(/\/$/)
  65  |   await expect(page.locator('[data-testid="canvas-root"]')).toBeVisible()
  66  | })
  67  | 
  68  | test('navigating to an unknown board id redirects to /', async ({ page }) => {
  69  |   await page.goto('/does-not-exist')
  70  |   await expect(page).toHaveURL(/\/$/)
  71  |   await expect(page.locator('[data-testid="canvas-root"]')).toBeVisible()
  72  | })
  73  | 
  74  | test('navigating to /root (the reserved root board id as a path segment) redirects to /', async ({
  75  |   page,
  76  | }) => {
  77  |   await page.goto('/root')
  78  |   await expect(page).toHaveURL(/\/$/)
  79  |   await expect(page.locator('[data-testid="canvas-root"]')).toBeVisible()
  80  | })
  81  | 
  82  | test('the breadcrumb shows only the home icon on root, with no editable title', async ({
  83  |   page,
  84  | }) => {
  85  |   await page.goto('/')
  86  |   await expect(page.locator('.breadcrumb__home')).toBeVisible()
> 87  |   await expect(page.locator('.breadcrumb__title')).toHaveCount(0)
      |                                                    ^ Error: expect(locator).toHaveCount(expected) failed
  88  | })
  89  | 
  90  | test("navigating to a second board shows only that board's own content, scoped independently of root", async ({
  91  |   page,
  92  | }) => {
  93  |   await seedBoard(page, TWO_BOARD_DOCUMENT, 'kanvy.board')
  94  |   await page.goto('/child-1')
  95  | 
  96  |   await expect(page).toHaveURL(/\/child-1$/)
  97  |   await expect(page.getByText('Child content')).toBeVisible()
  98  |   await expect(page.getByText('Root content')).toHaveCount(0)
  99  |   await expect(page.locator('.breadcrumb__title')).toHaveText('Untitled board')
  100 | 
  101 |   // Home icon still navigates back to root, showing root's own content
  102 |   // instead.
  103 |   await page.locator('.breadcrumb__home').click()
  104 |   await expect(page).toHaveURL(/\/$/)
  105 |   await expect(page.getByText('Root content')).toBeVisible()
  106 |   await expect(page.getByText('Child content')).toHaveCount(0)
  107 | })
  108 | 
  109 | test('breadcrumb title is a hover-to-edit control: pencil on hover, checkmark while editing, commits via checkmark click (design doc §6, shared with the on-canvas board name)', async ({
  110 |   page,
  111 | }) => {
  112 |   await seedBoard(page, TWO_BOARD_DOCUMENT, 'kanvy.board')
  113 |   await page.goto('/child-1')
  114 | 
  115 |   const title = page.locator('.breadcrumb__title')
  116 |   const editBtn = title.locator('.board-name__edit-btn')
  117 |   await expect(title.locator('.board-name__text')).toHaveText('Untitled board')
  118 | 
  119 |   await title.hover()
  120 |   await editBtn.click()
  121 |   const input = title.locator('.board-name__input')
  122 |   await expect(input).toBeFocused()
  123 |   await expect(title.locator('.board-name__edit-btn--confirm')).toBeVisible()
  124 |   await input.fill('Project Alpha')
  125 |   await title.locator('.board-name__edit-btn--confirm').click()
  126 | 
  127 |   await expect(title.locator('.board-name__text')).toHaveText('Project Alpha')
  128 |   await expect(title.locator('.board-name__input')).toHaveCount(0)
  129 | 
  130 |   // Persisted, not just in-memory. Autosave is debounced
  131 |   // (state/persistence/storage.ts, 500ms default) — poll for the write
  132 |   // landing rather than guessing a fixed wait. Deliberately not verified
  133 |   // via reload-and-re-read: `seedBoard`'s `page.addInitScript` re-runs on
  134 |   // every navigation (including `reload()`), which would re-seed the
  135 |   // original fixture and overwrite this very persistence, testing the
  136 |   // wrong thing.
  137 |   await expect
  138 |     .poll(() => page.evaluate(() => window.localStorage.getItem('kanvy.board')))
  139 |     .toContain('Project Alpha')
  140 | })
  141 | 
  142 | test('breadcrumb rename commits via Enter too, not just the checkmark', async ({
  143 |   page,
  144 | }) => {
  145 |   await seedBoard(page, TWO_BOARD_DOCUMENT, 'kanvy.board')
  146 |   await page.goto('/child-1')
  147 | 
  148 |   const title = page.locator('.breadcrumb__title')
  149 |   await title.hover()
  150 |   await title.locator('.board-name__edit-btn').click()
  151 |   await title.locator('.board-name__input').fill('Committed via Enter')
  152 |   await page.keyboard.press('Enter')
  153 |   await expect(title.locator('.board-name__text')).toHaveText(
  154 |     'Committed via Enter',
  155 |   )
  156 | })
  157 | 
  158 | test('breadcrumb rename discards the draft on Escape or on blur — a checkmark-confirm UI would be pointless if either committed anyway', async ({
  159 |   page,
  160 | }) => {
  161 |   await seedBoard(page, TWO_BOARD_DOCUMENT, 'kanvy.board')
  162 |   await page.goto('/child-1')
  163 | 
  164 |   const title = page.locator('.breadcrumb__title')
  165 | 
  166 |   await title.hover()
  167 |   await title.locator('.board-name__edit-btn').click()
  168 |   await title.locator('.board-name__input').fill('Should not stick (Escape)')
  169 |   await page.keyboard.press('Escape')
  170 |   await expect(title.locator('.board-name__text')).toHaveText('Untitled board')
  171 | 
  172 |   // Blurring (clicking away) without hitting Enter/checkmark also discards
  173 |   // — only an explicit commit (Enter or the checkmark) should save.
  174 |   await title.hover()
  175 |   await title.locator('.board-name__edit-btn').click()
  176 |   await title.locator('.board-name__input').fill('Should not stick (blur)')
  177 |   await page.locator('.breadcrumb__home').focus()
  178 |   await expect(title.locator('.board-name__text')).toHaveText('Untitled board')
  179 | })
  180 | 
  181 | // The default fresh-install seed board (schema/seed.ts) already has a
  182 | // "Welcome to Kanvy" text card on root — these scenarios need a genuinely
  183 | // empty root to make single-card assertions meaningful.
  184 | const EMPTY_ROOT_DOCUMENT = {
  185 |   version: 3,
  186 |   nodes: [],
  187 |   edges: [],
```