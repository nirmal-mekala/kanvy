# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: errorHandlingA11yTouch.spec.ts >> corrupt-save recovery UI (spec §9/Q12) >> shows a recovery toast and suppresses autosave until dismissed
- Location: e2e/errorHandlingA11yTouch.spec.ts:36:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('.toast')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('.toast') with timeout 5000ms
  - waiting for locator('.toast')

```

```yaml
- text: kanvy
- link "Home":
  - /url: /
- button "Change view mode"
- button "Switch to dark mode"
- button "Import a board from a JSON file"
- button "Download the board as a JSON file"
- button "Settings"
- button "My Kanvy Board"
- button "Edit board name"
- button "Keyboard shortcuts"
- switch "Switch to Network mode"
- button "Zoom out"
- button "100%"
- button "Zoom in"
- button "Open Tanstack query devtools":
  - img
```

# Test source

```ts
  1   | import { expect, test } from '@playwright/test'
  2   | import { seedBoard } from './fixtures/board'
  3   | 
  4   | // Stage 9 (error handling, a11y, touch) — spec §9, §11, §12.
  5   | //
  6   | // Run and passing (all 4) via the playwright-remote-browser skill — see
  7   | // AGENTS.md and ctx/notes/260915-phase6-e2e-test-scenario-checklist.md.
  8   | // The touch-drag spec needed `hasTouch: true` added to
  9   | // playwright.config.ts's `use` block, which wasn't set anywhere before.
  10  | 
  11  | test.describe('import-failure UI (spec §9/Q14)', () => {
  12  |   test('shows a dismissible toast, not window.alert, on a bad import file', async ({
  13  |     page,
  14  |   }) => {
  15  |     await page.goto('/')
  16  |     const [fileChooser] = await Promise.all([
  17  |       page.waitForEvent('filechooser'),
  18  |       page.locator('button[title="Import a board from a JSON file"]').click(),
  19  |     ])
  20  |     await fileChooser.setFiles({
  21  |       name: 'not-a-board.json',
  22  |       mimeType: 'application/json',
  23  |       buffer: Buffer.from('{ this is not valid json'),
  24  |     })
  25  | 
  26  |     const toast = page.locator('.toast')
  27  |     await expect(toast).toBeVisible()
  28  |     await expect(toast).toContainText('Could not import')
  29  | 
  30  |     await toast.locator('.toast__dismiss').click()
  31  |     await expect(toast).toBeHidden()
  32  |   })
  33  | })
  34  | 
  35  | test.describe('corrupt-save recovery UI (spec §9/Q12)', () => {
  36  |   test('shows a recovery toast and suppresses autosave until dismissed', async ({
  37  |     page,
  38  |   }) => {
  39  |     await page.addInitScript(() => {
  40  |       window.localStorage.setItem('kanvy.board', '{ not json at all')
  41  |     })
  42  |     await page.goto('/')
  43  | 
  44  |     const toast = page.locator('.toast')
> 45  |     await expect(toast).toBeVisible()
      |                         ^ Error: expect(locator).toBeVisible() failed
  46  |     await expect(toast).toContainText("couldn't be read")
  47  | 
  48  |     // The corrupt bytes must still be sitting in storage, untouched, until
  49  |     // the user acknowledges the toast.
  50  |     const stored = await page.evaluate(() =>
  51  |       window.localStorage.getItem('kanvy.board'),
  52  |     )
  53  |     expect(stored).toBe('{ not json at all')
  54  | 
  55  |     await toast.locator('.toast__dismiss').click()
  56  |     await expect(toast).toBeHidden()
  57  |   })
  58  | })
  59  | 
  60  | test.describe('baseline a11y (spec §11)', () => {
  61  |   test('toolbar buttons and help panel expose accessible names/roles', async ({
  62  |     page,
  63  |   }) => {
  64  |     await page.goto('/')
  65  |     await expect(page.locator('button[title="Change view mode"]')).toBeVisible()
  66  |     await expect(
  67  |       page.locator('button[title="Keyboard shortcuts"]'),
  68  |     ).toBeVisible()
  69  | 
  70  |     await page.locator('button[title="Keyboard shortcuts"]').click()
  71  |     await expect(
  72  |       page.locator('[role="dialog"][aria-label="Keyboard shortcuts"]'),
  73  |     ).toBeVisible()
  74  |     await page.keyboard.press('Escape')
  75  |     await expect(page.locator('[role="dialog"]')).toBeHidden()
  76  |   })
  77  | 
  78  |   test('a meaningful card image has non-empty alt text', async ({ page }) => {
  79  |     await seedBoard(
  80  |       page,
  81  |       {
  82  |         nodes: [
  83  |           {
  84  |             id: 'img-1',
  85  |             type: 'card',
  86  |             kind: 'image',
  87  |             imageId: 'image-1',
  88  |             x: 100,
  89  |             y: 100,
  90  |             w: 224,
  91  |             h: 160,
  92  |             color: 'gray',
  93  |             content: 'A photo of a cat',
  94  |             createdAt: '2026-01-01T00:00:00.000Z',
  95  |             updatedAt: '2026-01-01T00:00:00.000Z',
  96  |           },
  97  |         ],
  98  |         edges: [],
  99  |         images: {
  100 |           'image-1':
  101 |             'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBTAA7',
  102 |         },
  103 |       },
  104 |       'kanvy.board',
  105 |     )
  106 |     await page.goto('/')
  107 |     const alt = await page
  108 |       .locator('[data-node-id="img-1"]:not(.node-connector) img')
  109 |       .getAttribute('alt')
  110 |     expect(alt).toBe('A photo of a cat')
  111 |   })
  112 | 
  113 |   test('respects prefers-reduced-motion', async ({ page }) => {
  114 |     await page.emulateMedia({ reducedMotion: 'reduce' })
  115 |     await page.goto('/')
  116 |     const transition = await page.evaluate(
  117 |       () => getComputedStyle(document.body).transitionDuration,
  118 |     )
  119 |     expect(transition).toBe('0s')
  120 |   })
  121 | })
  122 | 
  123 | test.describe('basic touch support (spec §12)', () => {
  124 |   test('a single-finger touch drag moves a card', async ({
  125 |     page,
  126 |     browserName,
  127 |   }) => {
  128 |     test.skip(
  129 |       browserName !== 'chromium',
  130 |       'touch emulation is Chromium-only here',
  131 |     )
  132 |     await seedBoard(
  133 |       page,
  134 |       {
  135 |         nodes: [
  136 |           {
  137 |             id: 'touch-a',
  138 |             type: 'card',
  139 |             kind: 'text',
  140 |             size: 'regular',
  141 |             x: 100,
  142 |             y: 100,
  143 |             w: 224,
  144 |             h: 90,
  145 |             color: 'gray',
```