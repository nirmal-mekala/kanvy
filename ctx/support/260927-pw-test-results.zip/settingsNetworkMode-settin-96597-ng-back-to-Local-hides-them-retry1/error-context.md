# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: settingsNetworkMode.spec.ts >> settings modal (network mode design doc §2) >> toggling to Network reveals base URL/token fields; toggling back to Local hides them
- Location: e2e/settingsNetworkMode.spec.ts:119:3

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  getByPlaceholder('http://localhost:1996')
Expected: 0
Received: 1
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" getByPlaceholder('http://localhost:1996') with timeout 5000ms
  - waiting for getByPlaceholder('http://localhost:1996')
    14 × locator resolved to 1 element
       - unexpected value "1"

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - generic [ref=e3]:
    - generic [ref=e4]:
      - button "Close settings" [ref=e5]
      - dialog [ref=e6]:
        - heading "Connection settings" [level=2] [ref=e7]
        - generic [ref=e12]:
          - generic [ref=e13]:
            - generic [ref=e14]: Base URL
            - textbox "Base URL" [ref=e15]:
              - /placeholder: http://localhost:1996
          - generic [ref=e16]:
            - generic [ref=e17]: Auth token (optional)
            - textbox "Auth token (optional)" [ref=e18]:
              - /placeholder: "Sent as Authorization: Bearer <token>"
          - generic [ref=e19]:
            - checkbox "Persist token to this browser's local storage" [ref=e20]
            - generic [ref=e21]: Persist token to this browser's local storage
        - generic [ref=e22]:
          - button "Cancel" [ref=e23] [cursor=pointer]
          - button "Save & Connect" [disabled] [ref=e24]
    - generic [ref=e25]:
      - generic [ref=e26]: kanvy
      - link "Home" [ref=e28] [cursor=pointer]:
        - /url: /
      - button "Change view mode" [ref=e33] [cursor=pointer]
      - button "Switch to dark mode" [ref=e37] [cursor=pointer]
      - button "Import a board from a JSON file" [ref=e40] [cursor=pointer]
      - button "Download the board as a JSON file" [ref=e44] [cursor=pointer]
      - button "Settings" [active] [ref=e48] [cursor=pointer]
    - generic [ref=e54]:
      - button "Keyboard shortcuts" [ref=e55] [cursor=pointer]
      - switch "Switch to Network mode" [ref=e59] [cursor=pointer]
      - generic [ref=e63]:
        - button "Zoom out" [ref=e64] [cursor=pointer]
        - button "100%" [ref=e68] [cursor=pointer]
        - button "Zoom in" [ref=e69] [cursor=pointer]
  - button "Open Tanstack query devtools" [ref=e123] [cursor=pointer]
```

# Test source

```ts
  25  |   edges: [],
  26  |   boards: [
  27  |     {
  28  |       id: 'root',
  29  |       title: 'Home',
  30  |       status: 'active',
  31  |       createdAt: '2026-01-01T00:00:00.000Z',
  32  |       updatedAt: '2026-01-01T00:00:00.000Z',
  33  |     },
  34  |   ],
  35  |   images: [],
  36  | }
  37  | 
  38  | // Network mode / backend integration (ctx/notes/260923-network-mode-
  39  | // backend-integration-design.md, ctx/prompt/260923-network-mode-backend-
  40  | // integration.md §8): settings modal flow (toggle, connection-test
  41  | // failure, connection-test success + apply) and a basic network-mode
  42  | // board load/edit round trip against a real json-server instance.
  43  | //
  44  | // json-server must bind a port the *browser* (possibly remote, per the
  45  | // playwright-remote-browser skill) can reach — this container's actually-
  46  | // forwarded range is 1993-1997 (KANVY_E2E_PORT itself typically claims
  47  | // 1993 for the Vite dev server), not an arbitrary port. Every test below
  48  | // reuses this same single port rather than offsetting per-test — safe only
  49  | // because `test.describe.configure({ mode: 'serial' })` above guarantees
  50  | // no two of this file's `startJsonServer` calls are ever live at once.
  51  | // Other network-mode spec files (e.g. networkModeCrud.spec.ts) must use a
  52  | // *different* default port and env var — Playwright still runs separate
  53  | // files concurrently across workers even though this one's own tests are
  54  | // serialized.
  55  | const JSON_SERVER_PORT = Number(process.env.KANVY_E2E_JSON_SERVER_PORT ?? 1996)
  56  | 
  57  | const NOW = '2026-01-01T00:00:00.000Z'
  58  | 
  59  | function sampleDb() {
  60  |   return {
  61  |     boards: [
  62  |       {
  63  |         id: 'root',
  64  |         title: 'Home',
  65  |         status: 'active',
  66  |         createdAt: NOW,
  67  |         updatedAt: NOW,
  68  |       },
  69  |       {
  70  |         id: 'b1',
  71  |         title: 'Network board',
  72  |         status: 'active',
  73  |         createdAt: NOW,
  74  |         updatedAt: NOW,
  75  |       },
  76  |     ],
  77  |     nodes: [
  78  |       {
  79  |         id: 'n0',
  80  |         boardId: 'root',
  81  |         type: 'card',
  82  |         kind: 'board',
  83  |         boardRef: 'b1',
  84  |         x: 88,
  85  |         y: 104,
  86  |         w: 224,
  87  |         h: 90,
  88  |         color: 'gray',
  89  |         status: 'active',
  90  |         index: 0,
  91  |         content: '',
  92  |         createdAt: NOW,
  93  |         updatedAt: NOW,
  94  |       },
  95  |       {
  96  |         id: 'n1',
  97  |         boardId: 'b1',
  98  |         type: 'card',
  99  |         kind: 'text',
  100 |         size: 'regular',
  101 |         x: 80,
  102 |         y: 100,
  103 |         w: 224,
  104 |         h: 90,
  105 |         color: 'amber',
  106 |         status: 'active',
  107 |         index: 0,
  108 |         content: 'From the network',
  109 |         createdAt: NOW,
  110 |         updatedAt: NOW,
  111 |       },
  112 |     ],
  113 |     edges: [],
  114 |     images: [],
  115 |   }
  116 | }
  117 | 
  118 | test.describe('settings modal (network mode design doc §2)', () => {
  119 |   test('toggling to Network reveals base URL/token fields; toggling back to Local hides them', async ({
  120 |     page,
  121 |   }) => {
  122 |     await seedBoard(page, EMPTY_LOCAL_DOCUMENT, 'kanvy.board')
  123 |     await page.goto('/')
  124 |     await page.getByTitle('Settings').click()
> 125 |     await expect(page.getByPlaceholder('http://localhost:1996')).toHaveCount(0)
      |                                                                  ^ Error: expect(locator).toHaveCount(expected) failed
  126 | 
  127 |     await page.getByRole('button', { name: 'Network' }).click()
  128 |     await expect(page.getByPlaceholder('http://localhost:1996')).toBeVisible()
  129 | 
  130 |     await page.getByRole('button', { name: 'Local' }).click()
  131 |     await expect(page.getByPlaceholder('http://localhost:1996')).toHaveCount(0)
  132 |   })
  133 | 
  134 |   test('Confirm with an unreachable base URL keeps the modal open with an inline error', async ({
  135 |     page,
  136 |   }) => {
  137 |     await seedBoard(page, EMPTY_LOCAL_DOCUMENT, 'kanvy.board')
  138 |     await page.goto('/')
  139 |     await page.getByTitle('Settings').click()
  140 |     await page.getByRole('button', { name: 'Network' }).click()
  141 |     await page
  142 |       .getByPlaceholder('http://localhost:1996')
  143 |       .fill('http://localhost:1')
  144 |     await page.getByRole('button', { name: 'Confirm' }).click()
  145 | 
  146 |     await expect(page.getByText(/Could not connect/)).toBeVisible()
  147 |     // Still open — the toggle/fields are still there.
  148 |     await expect(page.getByPlaceholder('http://localhost:1996')).toBeVisible()
  149 |   })
  150 | 
  151 |   test('Confirm against a reachable backend applies network mode and hides Upload', async ({
  152 |     page,
  153 |   }) => {
  154 |     const server = await startJsonServer(sampleDb(), JSON_SERVER_PORT)
  155 |     try {
  156 |       await seedBoard(page, EMPTY_LOCAL_DOCUMENT, 'kanvy.board')
  157 |       await page.goto('/')
  158 |       await expect(
  159 |         page.getByTitle('Import a board from a JSON file'),
  160 |       ).toBeVisible()
  161 | 
  162 |       await page.getByTitle('Settings').click()
  163 |       await page.getByRole('button', { name: 'Network' }).click()
  164 |       await page
  165 |         .getByPlaceholder('http://localhost:1996')
  166 |         .fill(`http://localhost:${server.port}`)
  167 |       await page.getByRole('button', { name: 'Confirm' }).click()
  168 | 
  169 |       // Modal closes once the connection test + home-board load succeed.
  170 |       await expect(page.getByPlaceholder('http://localhost:1996')).toHaveCount(
  171 |         0,
  172 |         { timeout: 10_000 },
  173 |       )
  174 |       // Network mode hides Upload (design doc §3).
  175 |       await expect(
  176 |         page.getByTitle('Import a board from a JSON file'),
  177 |       ).toHaveCount(0)
  178 |     } finally {
  179 |       await server.stop()
  180 |     }
  181 |   })
  182 | })
  183 | 
  184 | test.describe('network mode board load/edit round trip (design doc §8)', () => {
  185 |   test('loads the home board from json-server, navigates to a child board, edits a card, and the edit persists via a real PATCH', async ({
  186 |     page,
  187 |   }) => {
  188 |     test.setTimeout(45_000)
  189 |     const server = await startJsonServer(sampleDb(), JSON_SERVER_PORT)
  190 |     try {
  191 |       await seedBoard(page, EMPTY_LOCAL_DOCUMENT, 'kanvy.board')
  192 |       await page.goto('/')
  193 |       await page.getByTitle('Settings').click()
  194 |       await page.getByRole('button', { name: 'Network' }).click()
  195 |       await page
  196 |         .getByPlaceholder('http://localhost:1996')
  197 |         .fill(`http://localhost:${server.port}`)
  198 |       await page.getByRole('button', { name: 'Confirm' }).click()
  199 |       await expect(page.getByPlaceholder('http://localhost:1996')).toHaveCount(
  200 |         0,
  201 |         { timeout: 10_000 },
  202 |       )
  203 | 
  204 |       // Home board renders the board-card fetched from json-server.
  205 |       await expect(page.locator('[data-testid="canvas-root"]')).toBeVisible()
  206 | 
  207 |       // Navigate into the child board (network mode design doc §6c) and
  208 |       // confirm its own network-fetched content renders. Clicking the
  209 |       // board card's icon+text activates (navigates in) — same click-to-
  210 |       // navigate semantics multiboard.spec.ts exercises for a board card.
  211 |       await page.locator('.board-name__activate').click()
  212 |       await expect(page.getByText('From the network')).toBeVisible({
  213 |         timeout: 10_000,
  214 |       })
  215 | 
  216 |       // Edit the card's content — network mode's write path (design doc
  217 |       // §5) maps this to a real PATCH /nodes/n1.
  218 |       // `.fill()` alone already dispatches the `input` event `Card.tsx`'s
  219 |       // onChange handler commits content from — no separate blur needed
  220 |       // (and `.blur()` here hangs: the card's own height-sync effect
  221 |       // re-measures on every content change, which keeps the element
  222 |       // "unstable" from Playwright's actionability check's point of view).
  223 |       await page
  224 |         .locator('.card', { hasText: 'From the network' })
  225 |         .locator('.card__content')
```