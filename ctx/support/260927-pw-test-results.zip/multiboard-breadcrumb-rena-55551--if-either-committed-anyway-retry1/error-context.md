# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: multiboard.spec.ts >> breadcrumb rename discards the draft on Escape or on blur — a checkmark-confirm UI would be pointless if either committed anyway
- Location: e2e/multiboard.spec.ts:158:1

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator:  locator('.breadcrumb__title').locator('.board-name__text')
Expected: "Untitled board"
Received: "Should not stick (blur)"
Timeout:  5000ms

Call log:
  - Expect "toHaveText" locator('.breadcrumb__title').locator('.board-name__text') with timeout 5000ms
  - waiting for locator('.breadcrumb__title').locator('.board-name__text')
    14 × locator resolved to <span class="board-name__text">Should not stick (blur)</span>
       - unexpected value "Should not stick (blur)"

```

```yaml
- text: Should not stick (blur)
```

# Test source

```ts
  78  |   await expect(page).toHaveURL(/\/$/)
  79  |   await expect(page.locator('[data-testid="canvas-root"]')).toBeVisible()
  80  | })
  81  | 
  82  | test('the breadcrumb shows only the home icon on root, with no editable title', async ({
  83  |   page,
  84  | }) => {
  85  |   await page.goto('/')
  86  |   await expect(page.locator('.breadcrumb__home')).toBeVisible()
  87  |   await expect(page.locator('.breadcrumb__title')).toHaveCount(0)
  88  | })
  89  | 
  90  | test("navigating to a second board shows only that board's own content, scoped independently of root", async ({
  91  |   page,
  92  | }) => {
  93  |   await seedBoard(page, TWO_BOARD_DOCUMENT, 'kanvy.board')
  94  |   await page.goto('/child-1')
  95  | 
  96  |   await expect(page).toHaveURL(/\/child-1$/)
  97  |   await expect(page.getByText('Child content')).toBeVisible()
  98  |   await expect(page.getByText('Root content')).toHaveCount(0)
  99  |   await expect(page.locator('.breadcrumb__title')).toHaveText('Untitled board')
  100 | 
  101 |   // Home icon still navigates back to root, showing root's own content
  102 |   // instead.
  103 |   await page.locator('.breadcrumb__home').click()
  104 |   await expect(page).toHaveURL(/\/$/)
  105 |   await expect(page.getByText('Root content')).toBeVisible()
  106 |   await expect(page.getByText('Child content')).toHaveCount(0)
  107 | })
  108 | 
  109 | test('breadcrumb title is a hover-to-edit control: pencil on hover, checkmark while editing, commits via checkmark click (design doc §6, shared with the on-canvas board name)', async ({
  110 |   page,
  111 | }) => {
  112 |   await seedBoard(page, TWO_BOARD_DOCUMENT, 'kanvy.board')
  113 |   await page.goto('/child-1')
  114 | 
  115 |   const title = page.locator('.breadcrumb__title')
  116 |   const editBtn = title.locator('.board-name__edit-btn')
  117 |   await expect(title.locator('.board-name__text')).toHaveText('Untitled board')
  118 | 
  119 |   await title.hover()
  120 |   await editBtn.click()
  121 |   const input = title.locator('.board-name__input')
  122 |   await expect(input).toBeFocused()
  123 |   await expect(title.locator('.board-name__edit-btn--confirm')).toBeVisible()
  124 |   await input.fill('Project Alpha')
  125 |   await title.locator('.board-name__edit-btn--confirm').click()
  126 | 
  127 |   await expect(title.locator('.board-name__text')).toHaveText('Project Alpha')
  128 |   await expect(title.locator('.board-name__input')).toHaveCount(0)
  129 | 
  130 |   // Persisted, not just in-memory. Autosave is debounced
  131 |   // (state/persistence/storage.ts, 500ms default) — poll for the write
  132 |   // landing rather than guessing a fixed wait. Deliberately not verified
  133 |   // via reload-and-re-read: `seedBoard`'s `page.addInitScript` re-runs on
  134 |   // every navigation (including `reload()`), which would re-seed the
  135 |   // original fixture and overwrite this very persistence, testing the
  136 |   // wrong thing.
  137 |   await expect
  138 |     .poll(() => page.evaluate(() => window.localStorage.getItem('kanvy.board')))
  139 |     .toContain('Project Alpha')
  140 | })
  141 | 
  142 | test('breadcrumb rename commits via Enter too, not just the checkmark', async ({
  143 |   page,
  144 | }) => {
  145 |   await seedBoard(page, TWO_BOARD_DOCUMENT, 'kanvy.board')
  146 |   await page.goto('/child-1')
  147 | 
  148 |   const title = page.locator('.breadcrumb__title')
  149 |   await title.hover()
  150 |   await title.locator('.board-name__edit-btn').click()
  151 |   await title.locator('.board-name__input').fill('Committed via Enter')
  152 |   await page.keyboard.press('Enter')
  153 |   await expect(title.locator('.board-name__text')).toHaveText(
  154 |     'Committed via Enter',
  155 |   )
  156 | })
  157 | 
  158 | test('breadcrumb rename discards the draft on Escape or on blur — a checkmark-confirm UI would be pointless if either committed anyway', async ({
  159 |   page,
  160 | }) => {
  161 |   await seedBoard(page, TWO_BOARD_DOCUMENT, 'kanvy.board')
  162 |   await page.goto('/child-1')
  163 | 
  164 |   const title = page.locator('.breadcrumb__title')
  165 | 
  166 |   await title.hover()
  167 |   await title.locator('.board-name__edit-btn').click()
  168 |   await title.locator('.board-name__input').fill('Should not stick (Escape)')
  169 |   await page.keyboard.press('Escape')
  170 |   await expect(title.locator('.board-name__text')).toHaveText('Untitled board')
  171 | 
  172 |   // Blurring (clicking away) without hitting Enter/checkmark also discards
  173 |   // — only an explicit commit (Enter or the checkmark) should save.
  174 |   await title.hover()
  175 |   await title.locator('.board-name__edit-btn').click()
  176 |   await title.locator('.board-name__input').fill('Should not stick (blur)')
  177 |   await page.locator('.breadcrumb__home').focus()
> 178 |   await expect(title.locator('.board-name__text')).toHaveText('Untitled board')
      |                                                    ^ Error: expect(locator).toHaveText(expected) failed
  179 | })
  180 | 
  181 | // The default fresh-install seed board (schema/seed.ts) already has a
  182 | // "Welcome to Kanvy" text card on root — these scenarios need a genuinely
  183 | // empty root to make single-card assertions meaningful.
  184 | const EMPTY_ROOT_DOCUMENT = {
  185 |   version: 3,
  186 |   nodes: [],
  187 |   edges: [],
  188 |   boards: [
  189 |     {
  190 |       id: 'root',
  191 |       title: 'Home',
  192 |       status: 'active',
  193 |       createdAt: NOW,
  194 |       updatedAt: NOW,
  195 |     },
  196 |   ],
  197 |   images: {},
  198 | }
  199 | 
  200 | test.describe('board card kind (Sub-phase 4)', () => {
  201 |   test('double-click on root creates a board card, not a text card', async ({
  202 |     page,
  203 |   }) => {
  204 |     await seedBoard(page, EMPTY_ROOT_DOCUMENT, 'kanvy.board')
  205 |     await page.goto('/')
  206 |     await page
  207 |       .locator('[data-testid="canvas-root"]')
  208 |       .dblclick({ position: { x: 400, y: 300 } })
  209 | 
  210 |     const card = page.locator('[data-testid="card"]')
  211 |     await expect(card).toHaveCount(1)
  212 |     await expect(card).toHaveClass(/card--board/)
  213 |   })
  214 | 
  215 |   test('a board card shows a "this is a board" icon centered in its drag bar, and its name on the canvas even when not selected', async ({
  216 |     page,
  217 |   }) => {
  218 |     await seedBoard(page, EMPTY_ROOT_DOCUMENT, 'kanvy.board')
  219 |     await page.goto('/')
  220 |     await page
  221 |       .locator('[data-testid="canvas-root"]')
  222 |       .dblclick({ position: { x: 400, y: 300 } })
  223 | 
  224 |     const boardCard = page.locator('[data-testid="card"]')
  225 |     await expect(boardCard).not.toHaveClass(/card--selected/)
  226 |     await expect(
  227 |       boardCard.locator('.card__bar .card__board-icon'),
  228 |     ).toBeVisible()
  229 |     await expect(boardCard.locator('.board-name__text')).toHaveText(
  230 |       'Untitled board',
  231 |     )
  232 |   })
  233 | 
  234 |   test('root only ever creates board/container nodes — text/image/link creation paths are disabled there (design doc §3)', async ({
  235 |     page,
  236 |   }) => {
  237 |     await seedBoard(page, EMPTY_ROOT_DOCUMENT, 'kanvy.board')
  238 |     await page.goto('/')
  239 | 
  240 |     // Plain-text OS-clipboard paste: normally creates a text card.
  241 |     await dispatchPaste(page, { text: 'hello from clipboard' })
  242 |     await expect(page.locator('[data-testid="card"]')).toHaveCount(0)
  243 | 
  244 |     // ⌘/Ctrl+N: normally creates an empty text card.
  245 |     await page.keyboard.press('ControlOrMeta+n')
  246 |     await expect(page.locator('[data-testid="card"]')).toHaveCount(0)
  247 |   })
  248 | 
  249 |   test('the full board-node lifecycle: create, rename on-canvas, navigate in, rename via breadcrumb, navigate out', async ({
  250 |     page,
  251 |   }) => {
  252 |     await seedBoard(page, EMPTY_ROOT_DOCUMENT, 'kanvy.board')
  253 |     await page.goto('/')
  254 | 
  255 |     await page
  256 |       .locator('[data-testid="canvas-root"]')
  257 |       .dblclick({ position: { x: 400, y: 300 } })
  258 |     const boardCard = page.locator('[data-testid="card"]')
  259 |     await expect(boardCard).toHaveClass(/card--board/)
  260 | 
  261 |     // The name row is always visible (not select-gated). Editing goes
  262 |     // through the shared hover-to-edit control: hover reveals a pencil,
  263 |     // clicking it swaps in the input plus a checkmark to confirm.
  264 |     const nameText = boardCard.locator('.board-name__text')
  265 |     await expect(nameText).toBeVisible()
  266 |     await boardCard.locator('.board-name').hover()
  267 |     await boardCard.locator('.board-name__edit-btn').click()
  268 |     await boardCard.locator('.board-name__input').fill('Project Alpha')
  269 |     await boardCard.locator('.board-name__edit-btn--confirm').click()
  270 |     await expect(nameText).toHaveText('Project Alpha')
  271 | 
  272 |     // Clicking the icon+text activates (navigates in) — same click-to-
  273 |     // navigate semantics the link card uses for its interior.
  274 |     await boardCard.locator('.board-name__activate').click()
  275 |     await expect(page).not.toHaveURL(/\/$/)
  276 |     await expect(
  277 |       page.locator('.breadcrumb__title .board-name__text'),
  278 |     ).toHaveText('Project Alpha')
```