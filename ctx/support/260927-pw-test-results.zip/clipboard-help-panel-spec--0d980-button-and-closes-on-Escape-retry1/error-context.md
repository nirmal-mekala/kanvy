# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: clipboard.spec.ts >> help panel (spec §4.2) >> opens via the ? button and closes on Escape
- Location: e2e/clipboard.spec.ts:704:3

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('.board__help')

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - generic [ref=e3]:
    - generic [ref=e4]:
      - generic [ref=e5]: kanvy
      - link "Home" [ref=e7] [cursor=pointer]:
        - /url: /
      - button "Change view mode" [ref=e12] [cursor=pointer]
      - button "Switch to dark mode" [ref=e16] [cursor=pointer]
      - button "Import a board from a JSON file" [ref=e19] [cursor=pointer]
      - button "Download the board as a JSON file" [ref=e23] [cursor=pointer]
      - button "Settings" [ref=e27] [cursor=pointer]
    - generic [ref=e33]:
      - button "Keyboard shortcuts" [ref=e34] [cursor=pointer]
      - switch "Switch to Network mode" [ref=e38] [cursor=pointer]
      - generic [ref=e42]:
        - button "Zoom out" [ref=e43] [cursor=pointer]
        - button "100%" [ref=e47] [cursor=pointer]
        - button "Zoom in" [ref=e48] [cursor=pointer]
  - button "Open Tanstack query devtools" [ref=e102] [cursor=pointer]
```

# Test source

```ts
  607 |     expect(nodes).toHaveLength(4)
  608 | 
  609 |     const domOrder = containers.map((c) => c.id)
  610 |     const rank = new Map(domOrder.map((id, i) => [id, i]))
  611 |     // The whole original subtree (parent, child) paints before the whole
  612 |     // duplicated one — not interleaved by depth.
  613 |     expect(rank.get('child')).toBeLessThan(rank.get(dupParentId) as number)
  614 |     expect(rank.get('parent')).toBeLessThan(rank.get(dupParentId) as number)
  615 |     expect(rank.get(dupParentId)).toBeLessThan(rank.get(dupChildId) as number)
  616 |   })
  617 | 
  618 |   test('a duplicate that lands outside the viewport pans it into view, without changing zoom (mirrors paste)', async ({
  619 |     page,
  620 |   }) => {
  621 |     await seed(page, {
  622 |       version: 1,
  623 |       nodes: [textCard('a', 100, 100)],
  624 |       edges: [],
  625 |       images: {},
  626 |     })
  627 |     await page.goto('/')
  628 |     await page
  629 |       .locator('[data-node-id="a"]:not(.node-connector) .card__bar')
  630 |       .click()
  631 | 
  632 |     // Pan far away so the duplicate (which lands near `a`'s world
  633 |     // position) ends up off-screen.
  634 |     const board = page.locator('[data-testid="canvas-root"]')
  635 |     const boardBox = await board.boundingBox()
  636 |     if (!boardBox) throw new Error('board not rendered')
  637 |     await page.mouse.move(boardBox.x + 200, boardBox.y + 200)
  638 |     await page.mouse.down({ button: 'right' })
  639 |     await page.mouse.move(boardBox.x + 200 - 2000, boardBox.y + 200 - 2000, {
  640 |       steps: 10,
  641 |     })
  642 |     await page.mouse.up({ button: 'right' })
  643 |     await expect(
  644 |       page.locator('[data-node-id="a"]:not(.node-connector)'),
  645 |     ).not.toBeInViewport()
  646 | 
  647 |     const zoomBefore = await page
  648 |       .locator('.board__layer')
  649 |       .evaluate((el) => (el as HTMLElement).style.transform)
  650 | 
  651 |     await page.keyboard.press('ControlOrMeta+d')
  652 | 
  653 |     const duplicate = page.locator(
  654 |       '[data-testid="card"]:not([data-node-id="a"])',
  655 |     )
  656 |     await expect(duplicate).toBeInViewport()
  657 | 
  658 |     const zoomAfter = await page
  659 |       .locator('.board__layer')
  660 |       .evaluate((el) => (el as HTMLElement).style.transform)
  661 |     const scaleOf = (t: string) => /scale\(([-\d.]+)\)/.exec(t)?.[1]
  662 |     expect(scaleOf(zoomAfter)).toBe(scaleOf(zoomBefore))
  663 |   })
  664 | 
  665 |   test('Backspace deletes the selection', async ({ page }) => {
  666 |     await seed(page, {
  667 |       version: 1,
  668 |       nodes: [textCard('a', 100, 100)],
  669 |       edges: [],
  670 |       images: {},
  671 |     })
  672 |     await page.goto('/')
  673 |     await page
  674 |       .locator('[data-node-id="a"]:not(.node-connector) .card__bar')
  675 |       .click()
  676 |     await page.keyboard.press('Backspace')
  677 |     await expect(
  678 |       page.locator('[data-node-id]:not(.node-connector)'),
  679 |     ).toHaveCount(0)
  680 |   })
  681 | 
  682 |   test('⌘/Ctrl+Z undoes a delete and restores the selection', async ({
  683 |     page,
  684 |   }) => {
  685 |     await seed(page, {
  686 |       version: 1,
  687 |       nodes: [textCard('a', 100, 100)],
  688 |       edges: [],
  689 |       images: {},
  690 |     })
  691 |     await page.goto('/')
  692 |     await page
  693 |       .locator('[data-node-id="a"]:not(.node-connector) .card__bar')
  694 |       .click()
  695 |     await page.keyboard.press('Backspace')
  696 |     await page.keyboard.press('ControlOrMeta+z')
  697 |     await expect(
  698 |       page.locator('[data-node-id="a"]:not(.node-connector)'),
  699 |     ).toHaveClass(/card--selected/)
  700 |   })
  701 | })
  702 | 
  703 | test.describe('help panel (spec §4.2)', () => {
  704 |   test('opens via the ? button and closes on Escape', async ({ page }) => {
  705 |     await seed(page, { version: 1, nodes: [], edges: [], images: {} })
  706 |     await page.goto('/')
> 707 |     await page.locator('.board__help').click()
      |                                        ^ Error: locator.click: Test timeout of 30000ms exceeded.
  708 |     await expect(page.locator('.help-panel')).toBeVisible()
  709 |     await page.keyboard.press('Escape')
  710 |     await expect(page.locator('.help-panel')).toBeHidden()
  711 |   })
  712 | 
  713 |   test('does not list a bare-key zoom-reset shortcut', async ({ page }) => {
  714 |     await seed(page, { version: 1, nodes: [], edges: [], images: {} })
  715 |     await page.goto('/')
  716 |     await page.locator('.board__help').click()
  717 |     await expect(page.locator('.help-panel')).not.toContainText(/^z$/i)
  718 |   })
  719 | })
  720 | 
```